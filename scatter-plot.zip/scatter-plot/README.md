# Scatter Plot

A Pen created on CodePen.io. Original URL: [https://codepen.io/hhasanelbadry/pen/GRQNZdG](https://codepen.io/hhasanelbadry/pen/GRQNZdG).

