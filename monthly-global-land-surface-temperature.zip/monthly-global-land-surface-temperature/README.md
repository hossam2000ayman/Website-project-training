# Monthly Global Land-Surface Temperature

A Pen created on CodePen.io. Original URL: [https://codepen.io/hhasanelbadry/pen/NWybNzJ](https://codepen.io/hhasanelbadry/pen/NWybNzJ).

