# 25 + 5 CLOCK

A Pen created on CodePen.io. Original URL: [https://codepen.io/hhasanelbadry/pen/rNJxMpL](https://codepen.io/hhasanelbadry/pen/rNJxMpL).

