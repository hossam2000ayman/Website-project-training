# D3 Bar Chart

A Pen created on CodePen.io. Original URL: [https://codepen.io/hhasanelbadry/pen/rNJWezV](https://codepen.io/hhasanelbadry/pen/rNJWezV).

